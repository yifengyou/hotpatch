#include <stdio.h>

void print_greetings(void)
{
	printf("Hello from UNPATCHED shared library\n");
}
